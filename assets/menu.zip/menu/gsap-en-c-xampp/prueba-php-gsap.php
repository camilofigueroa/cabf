<!--    Autor: Camilo Figueroa
        Este proyecto es una prueba de las librerias o componentes de Gsap en un proyecto web.
        El sitio de las librerias o clases es www.greensock.com
-->

<html>
    <head>
        <title>Prueba de Gsap</title>
        <script src="minified/TweenMax.min.js"></script>
        
    </head>
    
    <body>

        <?php

            for( $i = 1; $i <= 5; $i ++ )
            {
                echo "<div id='contenedor".$i."' style='position: absolute; border: dashed 1px; width: 100px; height: 100px;'>";
                echo "Este es el contenido de este div.";
                echo "</div>";
            }
        ?>

        <script>

            console.log( Math.random() );
            
            window.onload = function()
            {     
                var i;

                for( i = 1; i <= 5; i ++ )
                {
                    TweenMax.to( document.getElementById( "contenedor" + i ), Math.random(), { left: ( i * 100 ) +"px", onComplete: al_completar, onCompleteParams: [ document.getElementById( "contenedor" + i ) ] } );
                }

                function al_completar( contenedor )
                {
                    TweenMax.to( contenedor, 3, { border: "10px" } );
                }

                function aleatorio( maximo )
                {
                    return Math.floor(( Math.random() * maximo ) + 1 ); 
                }

            };
                
        </script>
                
    </body>
</html>